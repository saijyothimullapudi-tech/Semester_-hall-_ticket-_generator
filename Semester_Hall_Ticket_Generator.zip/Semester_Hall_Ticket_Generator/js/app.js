const $ = id => document.getElementById(id);
const DB = {
  users: 'sht_users',
  tickets: 'sht_tickets',
  college: 'sht_college',
  session: 'sht_session',
  schedules: 'sht_schedules'
};

let currentUser = null;
let collegeLogoData = '';
let latestTicket = null;

function read(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
}
function write(key, value) { localStorage.setItem(key, JSON.stringify(value)); }

function toast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2600);
}

function showView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
  const target = $(name + 'View');
  if (target) target.classList.remove('hidden');
  document.querySelectorAll('.nav-link').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
window.showView = showView;

function getUsers() { return read(DB.users, []); }
function getTickets() { return read(DB.tickets, []); }
function getSchedules() { return read(DB.schedules, {}); }

function seedAdmin() {
  let users = getUsers();
  if (!users.some(u => u.role === 'admin')) {
    users.push({ name: 'Administrator', email: 'admin@college.demo', password: 'admin123', role: 'admin' });
    write(DB.users, users);
  }
}

function addSubject(data = {}, isReadOnly = false) {
  const row = document.createElement('div');
  row.className = 'subject-row';
  const lockAttr = isReadOnly ? 'readonly' : '';
  const removeBtn = isReadOnly ? '' : `<button type="button" class="remove-subject" title="Remove subject">×</button>`;
  row.innerHTML = `
    <div class="subject-name">
      <label>Subject name</label>
      <input class="sub-name" required placeholder="e.g. Data Science" value="${escapeAttr(data.name || '')}" ${lockAttr}>
    </div>
    <div>
      <label>Exam date</label>
      <input class="sub-date" type="date" required value="${escapeAttr(data.date || '')}" ${lockAttr}>
    </div>
    <div>
      <label>Exam time</label>
      <input class="sub-time" type="time" required value="${escapeAttr(data.time || '')}" ${lockAttr}>
    </div>
    ${removeBtn}
  `;
  if (!isReadOnly) {
    row.querySelector('.remove-subject').onclick = () => {
      if ($('subjectsContainer').children.length > 1) row.remove();
      else toast('At least one subject is required.');
    };
  }
  $('subjectsContainer').appendChild(row);
}

function escapeAttr(s) {
  return String(s).replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}

function init() {
  seedAdmin();
  document.querySelectorAll('.nav-link').forEach(b => b.addEventListener('click', () => showView(b.dataset.view)));
  $('addSubjectBtn').onclick = () => addSubject();
  $('loginForm').addEventListener('submit', login);
  $('registerForm').addEventListener('submit', register);
  $('ticketForm').addEventListener('submit', generateTicket);
  $('clearFormBtn').onclick = clearTicketForm;
  $('saveCollegeBtn').onclick = saveCollege;
  $('collegeLogo').addEventListener('change', loadLogo);
  $('printTicketBtn').onclick = () => window.print();
  $('editTicketBtn').onclick = () => {
    $('ticketResult').classList.add('hidden');
    $('ticketForm').scrollIntoView({ behavior: 'smooth' });
  };
  $('showRecordsBtn').onclick = showRecords;
  $('hideRecordsBtn').onclick = () => $('recordsPanel').classList.add('hidden');
  $('exportBtn').onclick = exportRecords;

  // Reload schedule automatically when Admin changes Branch or Semester
  $('ticketBranch').addEventListener('change', () => { if (currentUser?.role === 'admin') loadScheduleIntoForm(false); });
  $('ticketSemester').addEventListener('change', () => { if (currentUser?.role === 'admin') loadScheduleIntoForm(false); });

  loadCollege();
  const saved = read(DB.session, null);
  if (saved) {
    const u = getUsers().find(x => x.email === saved.email);
    if (u) {
      currentUser = u;
      openDashboard();
    }
  }
}

function register(e) {
  e.preventDefault();
  const user = {
    name: $('regName').value.trim(),
    roll: $('regRoll').value.trim(),
    email: $('regEmail').value.trim().toLowerCase(),
    password: $('regPassword').value,
    branch: $('regBranch').value,
    semester: $('regSemester').value,
    role: 'student'
  };
  let users = getUsers();
  if (users.some(u => u.email === user.email)) { toast('An account with this email already exists.'); return; }
  if (users.some(u => u.roll && u.roll.toLowerCase() === user.roll.toLowerCase())) { toast('This roll number is already registered.'); return; }
  users.push(user);
  write(DB.users, users);
  write(DB.session, { email: user.email });
  currentUser = user;
  openDashboard();
  toast('Registration successful. Welcome!');
}

function login(e) {
  e.preventDefault();
  const email = $('loginEmail').value.trim().toLowerCase();
  const password = $('loginPassword').value;
  const role = $('loginRole').value;
  const user = getUsers().find(u => u.email === email && u.password === password && u.role === role);
  if (!user) { toast('Incorrect email, password or account type.'); return; }
  currentUser = user;
  write(DB.session, { email: user.email });
  openDashboard();
  toast('Login successful.');
}

function logout() {
  currentUser = null;
  localStorage.removeItem(DB.session);
  $('ticketResult').classList.add('hidden');
  showView('home');
  toast('You have logged out.');
}
window.logout = logout;

function getScheduleKey() {
  return `${$('ticketBranch').value}_${$('ticketSemester').value}`;
}

function loadScheduleIntoForm(isReadOnly) {
  const schedules = getSchedules();
  const savedSched = schedules[getScheduleKey()];
  $('subjectsContainer').innerHTML = '';

  if (savedSched && savedSched.subjects && savedSched.subjects.length) {
    $('ticketYear').value = savedSched.year || '2026–2027';
    $('ticketType').value = savedSched.type || 'Regular';
    savedSched.subjects.forEach(s => addSubject(s, isReadOnly));
  } else {
    if (isReadOnly) {
      $('subjectsContainer').innerHTML = '<p class="muted tiny">No exam timetable published by Administrator for your Branch & Semester yet.</p>';
    } else {
      addSubject({}, false);
      addSubject({}, false);
      addSubject({}, false);
    }
  }
}

function saveAdminSchedule() {
  const subjects = [...document.querySelectorAll('.subject-row')].map(r => ({
    name: r.querySelector('.sub-name').value.trim(),
    date: r.querySelector('.sub-date').value,
    time: r.querySelector('.sub-time').value
  }));
  if (!subjects.length || subjects.some(s => !s.name || !s.date || !s.time)) {
    toast('Complete all subject names, dates and times before publishing.');
    return;
  }
  const schedules = getSchedules();
  schedules[getScheduleKey()] = {
    year: $('ticketYear').value.trim(),
    type: $('ticketType').value,
    subjects
  };
  write(DB.schedules, schedules);
  toast(`Timetable published for ${$('ticketBranch').value} - ${$('ticketSemester').value} Sem!`);
}

function openDashboard() {
  showView('dashboard');
  const admin = currentUser.role === 'admin';
  $('welcomeTitle').textContent = admin ? 'Welcome, Administrator' : `Welcome, ${currentUser.name}`;
  $('adminTools').classList.toggle('hidden', !admin);
  $('statStudents').textContent = getUsers().filter(u => u.role === 'student').length;
  $('statTickets').textContent = getTickets().length;

  // Lock Institution settings for Students (Admin only)
  $('collegeName').readOnly = !admin;
  $('collegeLogo').classList.toggle('hidden', !admin);
  $('saveCollegeBtn').classList.toggle('hidden', !admin);

  // Add or show "Publish Timetable" button for Admin only
  let pubBtn = $('publishScheduleBtn');
  if (!pubBtn) {
    pubBtn = document.createElement('button');
    pubBtn.type = 'button';
    pubBtn.id = 'publishScheduleBtn';
    pubBtn.className = 'btn btn-outline';
    pubBtn.textContent = 'Publish Timetable for Students';
    pubBtn.onclick = saveAdminSchedule;
    $('clearFormBtn').parentNode.insertBefore(pubBtn, $('clearFormBtn'));
  }
  pubBtn.classList.toggle('hidden', !admin);

  if (!admin) {
    // Student View: Lock all profile & schedule inputs
    $('ticketName').value = currentUser.name || '';
    $('ticketRoll').value = currentUser.roll || '';
    $('ticketBranch').value = currentUser.branch || 'CSE';
    $('ticketSemester').value = currentUser.semester || '7th';

    $('ticketName').readOnly = true;
    $('ticketRoll').readOnly = true;
    $('ticketYear').readOnly = true;
    $('ticketBranch').disabled = true;
    $('ticketSemester').disabled = true;
    $('ticketType').disabled = true;

    $('addSubjectBtn').classList.add('hidden');
    $('clearFormBtn').classList.add('hidden');
    $('editTicketBtn').classList.add('hidden');

    loadScheduleIntoForm(true);
  } else {
    // Admin View: Unlock all inputs to configure schedules or generate tickets
    $('ticketName').value = '';
    $('ticketRoll').value = '';
    $('ticketName').readOnly = false;
    $('ticketRoll').readOnly = false;
    $('ticketYear').readOnly = false;
    $('ticketBranch').disabled = false;
    $('ticketSemester').disabled = false;
    $('ticketType').disabled = false;

    $('addSubjectBtn').classList.remove('hidden');
    $('clearFormBtn').classList.remove('hidden');
    $('editTicketBtn').classList.remove('hidden');

    loadScheduleIntoForm(false);
  }
}

function loadCollege() {
  const c = read(DB.college, { name: '[COLLEGE NAME]', logo: '' });
  $('collegeName').value = c.name || '';
  collegeLogoData = c.logo || '';
  $('logoStatus').textContent = collegeLogoData ? 'Logo uploaded' : 'No logo uploaded';
}

function loadLogo(e) {
  const file = e.target.files[0];
  if (!file) return;
  if (file.size > 1.5 * 1024 * 1024) {
    toast('Please choose an image smaller than 1.5 MB.');
    e.target.value = '';
return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    collegeLogoData = reader.result;
    $('logoStatus').textContent = 'Logo selected. Save college details.';
  };
  reader.readAsDataURL(file);
}

function saveCollege() {
  const name = $('collegeName').value.trim();
  if (!name) { toast('Enter your college name.'); return; }
  write(DB.college, { name, logo: collegeLogoData });
  toast('College details saved.');
}

function clearTicketForm() {
  if (currentUser && currentUser.role === 'student') return;
  $('ticketName').value = '';
  $('ticketRoll').value = '';
  $('ticketYear').value = '2026–2027';
  $('ticketType').value = 'Regular';
  $('subjectsContainer').innerHTML = '';
  addSubject();
  addSubject();
  addSubject();
  $('ticketResult').classList.add('hidden');
}

function generateTicket(e) {
  e.preventDefault();
  const subjects = [...document.querySelectorAll('.subject-row')].map(r => ({
    name: r.querySelector('.sub-name').value.trim(),
    date: r.querySelector('.sub-date').value,
    time: r.querySelector('.sub-time').value
  }));
  if (!subjects.length || subjects.some(s => !s.name || !s.date || !s.time)) {
    toast(currentUser.role === 'student'
      ? 'Exam timetable not yet published by Administrator.'
      : 'Complete all subject names, dates and times.');
    return;
  }
  const c = read(DB.college, { name: '[COLLEGE NAME]', logo: '' });
  const ticket = {
    id: 'SHT-' + Date.now(),
    college: c.name || '[COLLEGE NAME]',
    logo: c.logo || '',
    name: $('ticketName').value.trim(),
    roll: $('ticketRoll').value.trim(),
    branch: $('ticketBranch').value,
    semester: $('ticketSemester').value,
    year: $('ticketYear').value.trim(),
    type: $('ticketType').value,
    subjects,
    created: new Date().toISOString()
  };
  if (!ticket.name || !ticket.roll) {
    toast('Enter student name and roll number.');
    return;
  }
  latestTicket = ticket;
  let tickets = getTickets();
  tickets.push(ticket);
  write(DB.tickets, tickets);
  renderTicket(ticket);
  $('ticketResult').classList.remove('hidden');
  $('statTickets').textContent = getTickets().length;
  $('ticketResult').scrollIntoView({ behavior: 'smooth' });
  toast('Hall ticket generated successfully.');
}

function formatDate(value) {
  if (!value) return '';
  return new Date(value + 'T00:00:00').toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function renderTicket(t) {
  const paper = $('ticketPaper');
  paper.innerHTML = `
    ${t.logo ? `<img class="ticket-logo" src="${t.logo}" alt="College logo">` : ''}
    <h1 class="ticket-college">${escapeHtml(t.college)}</h1>
    <p class="ticket-subtitle">SEMESTER END EXAMINATION – HALL TICKET</p>
    <div class="ticket-info">
      <div>Student Name: <b>${escapeHtml(t.name)}</b></div>
      <div>Roll Number: <b>${escapeHtml(t.roll)}</b></div>
      <div>Branch: <b>${escapeHtml(t.branch)}</b></div>
      <div>Semester: <b>${escapeHtml(t.semester)}</b></div>
      <div>Academic Year: <b>${escapeHtml(t.year)}</b></div>
      <div>Exam Type: <b>${escapeHtml(t.type)}</b></div>
    </div>
    <h2 class="ticket-section-title">Subjects / Examination Schedule</h2>
    <table class="ticket-subjects">
      <thead><tr><th>#</th><th>Subject</th><th>Examination Date</th><th>Time</th></tr></thead>
      <tbody>${t.subjects.map((s, i) => `<tr><td>${i + 1}</td><td>${escapeHtml(s.name)}</td><td>${formatDate(s.date)}</td><td>${escapeHtml(s.time)}</td></tr>`).join('')}</tbody>
    </table>
    <div class="ticket-signatures">
      <span>Student Signature:<i class="signature-line"></i></span>
      <span>Controller of Examinations:<i class="signature-line"></i></span>
    </div>
    <div class="ticket-footer">
      <span class="tiny">Generated: ${new Date(t.created).toLocaleDateString('en-IN')}</span>
      <div id="ticketQr" class="qr-box"></div>
    </div>
  `;
  if (window.QRCode) {
    new QRCode($('ticketQr'), {
      text: `${t.id}|${t.roll}|${t.name}|${t.semester}`,
      width: 75,
      height: 75,
      colorDark: '#193653',
      colorLight: '#ffffff',
      correctLevel: QRCode.CorrectLevel.M
    });
  }
}

function escapeHtml(s) {
  return String(s ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", "'");
}

function showRecords() {
  const rows = getUsers().filter(u => u.role === 'student');
  $('recordsBody').innerHTML = rows.length
    ? rows.map(u => `<tr><td>${escapeHtml(u.name)}</td><td>${escapeHtml(u.roll || '-')}</td><td>${escapeHtml(u.email)}</td><td>${escapeHtml(u.branch || '-')}</td><td>${escapeHtml(u.semester || '-')}</td></tr>`).join('')
    : '<tr><td colspan="5">No student records yet.</td></tr>';
  $('recordsPanel').classList.remove('hidden');
  $('recordsPanel').scrollIntoView({ behavior: 'smooth' });
}

function exportRecords() {
  const data = {
    users: getUsers().filter(u => u.role === 'student').map(({ password, ...u }) => u),
    tickets: getTickets()
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'hall-ticket-demo-records.json';
  a.click();
  URL.revokeObjectURL(a.href);
  toast('Records export downloaded.');
}

document.addEventListener('DOMContentLoaded', init);