# Smart Semester Hall Ticket Generator

A beginner-friendly browser-based demo project built with HTML, CSS and JavaScript.

## How to run on Windows (no installation)

1. Download and extract `Smart_Semester_Hall_Ticket_Generator.zip`.
2. Open the extracted folder.
3. Double-click `index.html`.
4. The project opens in Chrome or Microsoft Edge.

## Demo administrator login
- Email: `admin@college.demo`
- Password: `admin123`
- Select account type: Administrator

## Student use
1. Select Student Registration.
2. Create an account using a unique email and roll number.
3. Log in as Student.
4. Fill subject names, exam dates and times.
5. Click Generate Hall Ticket.
6. Click Print / Save PDF.
7. In the browser print dialog, choose "Save as PDF".

## Important notes
- This is a front-end demonstration. Data is saved in the browser's LocalStorage on the same device/browser.
- It does not provide secure real-world authentication or a shared online database.
- The QR code uses a library loaded from a CDN, so an internet connection is needed for QR generation.
- For actual college use and public multi-user access, connect a secure backend/database and implement proper authentication and authorization.
- Do not use sample/demo credentials or data for official examination records.
